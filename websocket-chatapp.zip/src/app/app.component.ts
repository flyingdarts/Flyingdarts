import { Component, OnInit } from '@angular/core';
import { WebSocketStatus } from './websocket/WebSocketStatus';
import { v4 as uuidv4 } from 'uuid';
import { WebSocketService } from './websocket/websocket.service';
import { filter } from 'rxjs';
import { WebSocketActions } from './websocket/WebSocketActions';
import { MessageRequest } from './websocket/WebSocketRequest';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  public messages: MessageRequest[] = [];
  public webSocketStatus: WebSocketStatus = WebSocketStatus.Unknown
  public clientId: string = ""
  
  constructor(
    private webSocketService: WebSocketService) {
  }

  messageForm = new FormGroup({
    message: new FormControl(''),
  })
  ngOnInit(): void {
    this.clientId = uuidv4();
    this.webSocketService.getMessages()
        .pipe(filter(x => x.action === WebSocketActions.Connect))
        .subscribe(x => {
          this.webSocketStatus = WebSocketStatus.Connected
        })

    this.webSocketService.getMessages()
        .pipe(filter(x => x.action === WebSocketActions.Disconnect))
        .subscribe(x => {
          this.webSocketStatus = WebSocketStatus.Disconnected
        })

    this.webSocketService.getMessages()
        .pipe(filter(x => x.action === WebSocketActions.Default))
        .subscribe(x => {
          this.messages.push(JSON.parse(x.message! as string) as MessageRequest)
        })
  }

  public send() {
    this.webSocketService.postMessage(JSON.stringify({
      action: "message",
      message: {
        date: new Date(),
        message: this.messageForm.value.message,
        owner: this.clientId,
      }
    }))
  }

}