export enum WebSocketStatus {
    Unknown = "WebSocket status unknown",
    Disconnected = "Lost connection to server.",
    Connected = "Connected."
}