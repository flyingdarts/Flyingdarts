
export enum WebSocketActions {
  Connect = "connect$",
  Disconnect = "disconnect$",
  Default = "default$"
}
