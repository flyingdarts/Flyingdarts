export const environment = {
  production: true,
  webSocketUrl: 'wss://ewwi6tm25a.execute-api.eu-west-1.amazonaws.com/Development'
};
